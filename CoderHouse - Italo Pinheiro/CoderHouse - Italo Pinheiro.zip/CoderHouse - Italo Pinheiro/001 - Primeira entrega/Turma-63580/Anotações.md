<!-- ctrl + ; cria um novo comentário -->
<!-- html5 ou ! identifica a linguagem da programaçãop -->
<!-- para criar uma "caixa de conteúdo deve-se utilizar main antes" -->
<!-- Para se referir ao main utiliza-se class dentro de secçao, texto ou outro -->
<!-- Para utilizar uma fonte, além da opção de instalar no computador, pode colocar o código dentro do style.css -->
<!-- !important; vai fazer que sobrescreva o código a força -->
 <!-- Sequencia de important é: important>id>class>tag -->

 <!-- https://www.w3schools.com/ --> biblioteca de possibilidades e tags e afins

 head importante e que vai carregar primeiro
 depois o miolo todo e no final motion e afins

nav = navegação
utilizado para determinar uma secção ou grupo que vai colocar de páginas da web
<!-- seguido por Li list item -->
<!-- ou ul lista não ordenada -->

:root {
    variaveis aplicados a todos os itend do projeto... como fontes de principal  h1 a h6
}

var(--primary)

height: 100vh
weight:100%

            <!-- </main style="display: flex">
            <h1>portfólio art abstract pexels 01</h1>
                <img src="https://cdn.pixabay.com/photo/2024/07/09/16/37/abstract-8884025_1280.png" alt="">
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Et eos quia ullam qui itaque quidem error cumque vero. Temporibus nostrum animi architecto nihil nulla impedit vero minima! Eaque, odit deserunt.</p>
            </main>
            
            <Section>
                <h1>portfólio art abstract pexels 02</h1>
                <img src="https://cdn.pixabay.com/photo/2024/07/09/16/37/abstract-8884025_1280.png" alt="">
            </Section> -->